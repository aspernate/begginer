package com.javarush.test.level22.lesson18.big01;

import java.awt.event.KeyEvent;

/**
 *  Класс Tetris - содержит основной функционал игры.
 */
public class Tetris
{
    private Field field;                //Поле с клетками
    private Figure figure;              //Фигурка

    private boolean isGameOver;         //Игра Окончена?

    public Tetris(int width, int height)
    {
        field = new Field(width, height);
        figure = null;
    }

    /**
     * Геттер переменной field.
     */
    public Field getField()
    {
        return field;
    }

    /**
     * Геттер переменной figure.
     */
    public Figure getFigure()
    {
        return figure;
    }

    /**
     *  Основной цикл программы.
     *  Тут происходят все важные действия
     */
    public void run() throws Exception
    {
        //Создаем объект "наблюдатель за клавиатурой" и стартуем его.
        KeyboardObserver keyboardObserver = new KeyboardObserver();
        keyboardObserver.start();

        //выставляем начальное значение переменной "игра окончена" в ЛОЖЬ
        isGameOver = false;
        //создаем первую фигурку посередине сверху: x - половина ширины, y - 0.
        figure = FigureFactory.createRandomFigure(field.getWidth() / 2, 0);

        //пока игра не окончена
        while (!isGameOver)
        {
            //"наблюдатель" содержит события о нажатии клавиш?
            if (keyboardObserver.hasKeyEvents())
            {
                //получить самое первое событие из очереди
                KeyEvent event = keyboardObserver.getEventFromTop();
                //Если равно символу 'q' - выйти из игры.
                if (event.getKeyChar() == 'q') return;
                //Если "стрелка влево" - сдвинуть фигурку влево
                if (event.getKeyCode() == KeyEvent.VK_LEFT)
                    figure.left();
                //Если "стрелка вправо" - сдвинуть фигурку вправо
                else if (event.getKeyCode() ==  KeyEvent.VK_RIGHT)
                    figure.right();
                //Если  код клавиши равен 12 ("цифра 5 на доп. клавиатуре") - повернуть фигурку
                else if (event.getKeyCode() ==  12)
                    figure.rotate();
                //Если "пробел" - фигурка падает вниз на максимум
                else if (event.getKeyCode() ==  KeyEvent.VK_SPACE)
                    figure.downMaximum();
            }

            step();             //делаем очередной шаг
            field.print();      //печатаем состояние "поля"
            Thread.sleep(300);  //пауза 300 миллисекунд - 1/3 секунды
        }

        //Выводим сообщение "Game Over"
        System.out.println("Game Over");
    }

    /**
     * Один шаг игры
     */
    public void step()
    {
        figure.down();
        if(!figure.isCurrentPositionAvailable()) {
            figure.up();
            figure.landed();
            if(figure.getY() == 0) {
                isGameOver = true;
            }
            field.removeFullLines();
            figure = FigureFactory.createRandomFigure(field.getWidth() / 2, 0);
        }
        //опускам фигурку вниз

        //если разместить фигурку на текущем месте невозможно:
            //поднимаем обратно
            //приземляем
            //если фигурка приземлилась на самом верху - игра окончена
            //удаляем заполненные линии
            //создаем новую фигурку


    }

    /**
     * Сеттер для figure
     */
    public void setFigure(Figure figure)
    {
        this.figure = figure;
    }

    /**
     * Сеттер для field
     */
    public void setField(Field field)
    {
        this.field = field;
    }

    public static Tetris game;
    public static void main(String[] args) throws Exception
    {
        game = new Tetris(10, 20);
        game.run();
    }
}
